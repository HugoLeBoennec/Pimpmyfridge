/* Auteur : Christophe Sulyven  */


#include <SoftwareSerial.h>
#include "DHT.h"
#define pinPeltier 3
#define pinVentilo 5
#define A 17.25f
#define B 237.7f
#define pinDHT 2
#define typeDHT DHT22
#define RX 4
#define TX 5
DHT dht (pinDHT, typeDHT);
void augmenter();
void maintenir();
void reduire();
int recevoir();
int changementADistance();
int changementPC();
void automatisme(double souhait);
byte buf[32];
double humidite, temperature, pointDeRosee, consigne, alpha;
int power = 0, i, test;
int peltier_level = map(power, 0, 99, 0, 255);
word octet_recu;    // mot qui reÃ§oit les trames Ã©mises
SoftwareSerial bluetooth(RX, TX);








